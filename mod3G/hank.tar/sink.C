#include <sink.h>

Sink::Sink() {
  //nothing yet  
}  

/*end of file*/
